<?php
    require_once '../models/Credito.php';
    

    switch ($_GET["op"]) {
       
        case 'insertar':
              $email = isset($_POST["email"]) ? trim($_POST["email"]) : "";
              $nombre = isset($_POST["nombre"]) ? trim($_POST["nombre"]) : "";
              $telefono = isset($_POST["telefono"]) ? trim($_POST["telefono"]) : "";
              $cedula = isset($_POST["cedula"]) ? trim($_POST["cedula"]) : "";
              $monto = isset($_POST["monto"]) ? trim($_POST["monto"]) : "";
              $estado = isset($_POST["estado"]) ? trim($_POST["estado"]) : 1;
              
              
                  $credito = new Credito();
                  $credito->setCedula($cedula);
                  $encontrado = $credito->verificarExistenciaDb();
                  if ($encontrado == false) {
                      $credito->setEmail($email);
                      $credito->setNombre($nombre);
                      $credito->setTelefono($telefono);
                      $credito->setCedula($cedula);
                      $credito->setMonto($monto);
                      $credito->setEstado($estado);
                      $credito->setEstadoSoli("pendiente");
                      $credito->guardarEnDb();
                      if($credito->verificarExistenciaDb()){
                          //if(enviarCorreo($email,$clave,$nombre)){
                              echo 1; //credito registrado y envio de correo exitos
                          //}else{
                            //  echo 4; //credito registrado y envio de correo fallido
                          //}
                      }else{
                          echo 3; //Fallo al realizar el registro
                      }
                  } else {
                      echo 2; //el credito ya existe
                  }
        break;
       
       
       
      
      }
?>