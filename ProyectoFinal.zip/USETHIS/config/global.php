<?php
//CONSTANTES
define('DB_NAME_MYSQL', 'proyecto_db');
define('DB_HOST_MYSQL', 'localhost');
define('DB_USER_MYSQL', 'root');
define('DB_PASSWORD_MYSQL', 'root');