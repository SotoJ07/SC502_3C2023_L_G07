<?php
require_once '../config/Conexion.php';

class Credito extends Conexion
{
    /*=============================================
	=            Atributos de la Clase            =
	=============================================*/
        protected static $cnx;
		private $id=null;
		private $email=null;
		private $nombre= null;
		private $telefono=null;
        private $cedula=null;
        private $monto=null;
		private $estado= null;
        private $estadoSoli=null;
		
	/*=====  End of Atributos de la Clase  ======*/

    /*=============================================
	=            Contructores de la Clase          =
	=============================================*/
        public function __construct(){}
    /*=====  End of Contructores de la Clase  ======*/

    /*=============================================
	=            Encapsuladores de la Clase       =
	=============================================*/
        public function getId()
        {
            return $this->id;
        }
        public function setId($id)
        {
            $this->id = $id;
        }

        public function getEmail()
        {
            return $this->email;
        }
        public function setEmail($email)
        {
            $this->email = $email;
        }

        public function getNombre()
        {
            return $this->nombre;
        }
        public function setNombre($nombre)
        {
            $this->nombre = $nombre;
        }

        public function getTelefono()
        {
            return $this->telefono;
        }
        public function setTelefono($telefono)
        {
            $this->telefono = $telefono;
        }

        public function getCedula()
        {
            return $this->cedula;
        }
        public function setCedula($cedula)
        {
            $this->cedula = $cedula;
        }
        
        public function getMonto()
        {
            return $this->monto;
        }
        public function setMonto($monto)
        {
            $this->monto = $monto;
        }

        public function getEstado()
        {
            return $this->estado;
        }
        public function setEstado($estado)
        {
            $this->estado = $estado;
        }
        

        public function getEstadoSoli() {
            return $this->estadoSoli;
        }

        public function setEstadoSoli($estadoSoli)
        {
            $this->estadoSoli = $estadoSoli;
        }
       
       
    /*=====  End of Encapsuladores de la Clase  ======*/

    /*=============================================
	=            Metodos de la Clase              =
	=============================================*/
        public static function getConexion(){
            self::$cnx = Conexion::conectar();
        }

        public static function desconectar(){
            self::$cnx = null;
        }

       

        public function verificarExistenciaDb(){
            $query = "SELECT * FROM credito where cedula=:cedula";
         try {
             self::getConexion();
                $resultado = self::$cnx->prepare($query);		
                $cedula= $this->getCedula();	
                $resultado->bindParam(":cedula",$cedula,PDO::PARAM_STR);
                $resultado->execute();
                self::desconectar();
                $encontrado = false;
                foreach ($resultado->fetchAll() as $reg) {
                    $encontrado = true;
                }
                return $encontrado;
               } catch (PDOException $Exception) {
                   self::desconectar();
                   $error = "Error ".$Exception->getCode().": ".$Exception->getMessage();
                 return $error;
               }
        }

        public function guardarEnDb(){
            $query = "INSERT INTO `credito`(`email`, `nombre`, `telefono`, `cedula`, `monto`, `estado`, `created_at`, `estadoSoli`) VALUES (:email,:nombre,:telefono,:cedula,:monto,:estado,now(), :estadoSoli)";
         try {
             self::getConexion();
             $email=$this->getEmail();
             $nombre=strtoupper($this->getNombre());
             $telefono=$this->getTelefono();
             $cedula=$this->getCedula();
             $monto=$this->getMonto();
             $estado=$this->getEstado();
             $estadoSoli=$this->getEstadoSoli();
    
            $resultado = self::$cnx->prepare($query);
            $resultado->bindParam(":email",$email,PDO::PARAM_STR);
            $resultado->bindParam(":nombre",$nombre,PDO::PARAM_STR);
            $resultado->bindParam(":telefono",$telefono,PDO::PARAM_STR);
            $resultado->bindParam(":cedula",$cedula,PDO::PARAM_STR);
            $resultado->bindParam(":monto",$monto,PDO::PARAM_STR);
            $resultado->bindParam(":estado",$estado,PDO::PARAM_INT);
            $resultado->bindParam(":estadoSoli",$estadoSoli,PDO::PARAM_STR);
          
                $resultado->execute();
                self::desconectar();
               } catch (PDOException $Exception) {
                   self::desconectar();
                   $error = "Error ".$Exception->getCode( ).": ".$Exception->getMessage( );;
                   return $error;
               }
        }

       


        

        public function llenarCampos($id){
            $query = "SELECT * FROM credito where id=:id";
            try {
            self::getConexion();
            $resultado = self::$cnx->prepare($query);		 	
            $resultado->bindParam(":id",$id,PDO::PARAM_INT);
            $resultado->execute();
            self::desconectar();
            foreach ($resultado->fetchAll() as $encontrado) {
                $this->setId($encontrado['id']);
                $this->setNombre($encontrado['nombre']);
                $this->setEstado($encontrado['estado']);
            }
            } catch (PDOException $Exception) {
            self::desconectar();
            $error = "Error ".$Exception->getCode().": ".$Exception->getMessage();;
            return json_encode($error);
            }
        }

        

        
        public function verificarExistenciaCedula(){
            $query = "SELECT cedula,id,nombre,telefono FROM credito where cedula=:cedula";
            try {
            self::getConexion();
            $resultado = self::$cnx->prepare($query);		
            $cedula= $this->getCedula();		
            $resultado->bindParam(":cedula",$cedula,PDO::PARAM_STR);
            $resultado->execute();
            self::desconectar();
            $encontrado = false;
            $arr=array();
            foreach ($resultado->fetchAll() as $reg) {
                $arr[]=$reg['id'];
                $arr[]=$reg['cedula'];   
                $arr[]=$reg['nombre'];  
                $arr[]=$reg['telefono'];  
            }
            return $arr;
            return $encontrado;
            } catch (PDOException $Exception) {
                self::desconectar();
                $error = "Error ".$Exception->getCode().": ".$Exception->getMessage();
            return $error;
            }
        }

        
    /*=====  End of Metodos de la Clase  ======*/  
}
?>